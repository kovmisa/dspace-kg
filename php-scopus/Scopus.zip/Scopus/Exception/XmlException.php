<?php

namespace Scopus\Exception;

use Exception;

class XmlException extends Exception 
{

}