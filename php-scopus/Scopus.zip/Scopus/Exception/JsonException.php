<?php

namespace Scopus\Exception;

use Exception;

class JsonException extends Exception
{

}